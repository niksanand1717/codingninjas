// Please don't change the pre-written code
// Import the necessary modules here
import { json } from "express";
import winston from "winston";

// Write your code here

const logger = winston.createLogger({
  level: "info",
  format: winston.format.json(),
  defaultMeta: { service: "user-service" },
  transports: [
    new winston.transports.File({ filename: "error.log", level: "error" }),
    new winston.transports.File({ filename: "combined.log" }),
  ],
});

export const loggerMiddleware = async (req, res, next) => {
  // Write your code here
  const body = req.body;
  console.log({ body });
  const message = ` ${new Date()} \n req URL: ${req.url} \n reqBody: ${body}`;
  const path = req.url;
  console.log(path);
  const logData = { message };
  logger.info(message);
};
export default loggerMiddleware;
